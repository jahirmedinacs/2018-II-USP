﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class CameraLookAt : MonoBehaviour {
    public Transform at;
    private void Update() {
        if(at != null)
            transform.rotation = Quaternion.LookRotation(at.position - transform.position);
    }
}
