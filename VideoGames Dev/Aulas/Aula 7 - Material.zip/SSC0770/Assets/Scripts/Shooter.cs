﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooter : MonoBehaviour {
    public GameObject bulletPrefab;
    public Transform[] spawnPoint;
    public LineRenderer ray;

    private int count;

    private void Start() {
        count = 0;
    }

    private void Update() {
        if (Input.GetButtonDown("Fire1")) {
            GameObject bullet = Instantiate<GameObject>(bulletPrefab, spawnPoint[count].position, Quaternion.identity);
            count = (count + 1) % spawnPoint.Length;
        }
        
        if (Input.GetButtonDown("Fire2")) {
            
            RaycastHit hit;
            if(Physics.Raycast(spawnPoint[count].position, Vector3.forward, out hit)) {
                print(name + ": Raycast Hit - " + hit.collider.name);
                ray.positionCount = 2;
                ray.SetPosition(0, spawnPoint[count].position);
                ray.SetPosition(1, hit.point);
            } else {
                print(name + ": Raycast Miss");
                ray.positionCount = 0;
            }
            count = (count + 1) % spawnPoint.Length;
        }
    }
}
