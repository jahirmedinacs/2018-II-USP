﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Bullet : MonoBehaviour {
    public float lifetime;
    public Vector3 velocity;

    private float timer;

    private void Start() {
        timer = Time.time;
        GetComponent<Rigidbody>().velocity = velocity;
    }

    private void Update() {
        if (Time.time - timer > lifetime)
            Destroy(gameObject);
    }
}
