﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrintCollision : MonoBehaviour {
    public bool collision, trigger;
    public bool enter, stay, exit;
    private void OnCollisionEnter(Collision collision) {
        if (this.collision && enter)
            print(name + ": Collision Enter 3D - " + collision.gameObject.name);
    }
    private void OnCollisionEnter2D(Collision2D collision) {
        if (this.collision && enter)
            print(name + ": Collision Enter 2D - " + collision.gameObject.name);
    }
    private void OnCollisionStay(Collision collision) {
        if (this.collision && stay)
            print(name + ": Collision Stay 3D - " + collision.gameObject.name);
    }
    private void OnCollisionStay2D(Collision2D collision) {
        if (this.collision && stay)
            print(name + ": Collision Stay 2D - " + collision.gameObject.name);
    }
    private void OnCollisionExit(Collision collision) {
        if (this.collision && exit)
            print(name + ": Collision Exit 3D - " + collision.gameObject.name);
    }
    private void OnCollisionExit2D(Collision2D collision) {
        if (this.collision && exit)
            print(name + ": Collision Exit 2D - " + collision.gameObject.name);
    }



    private void OnTriggerEnter(Collider collision) {
        if (trigger && enter)
            print(name + ": Trigger Enter 3D - " + collision.gameObject.name);
    }
    private void OnTriggerEnter2D(Collider2D collision) {
        if (trigger && enter)
            print(name + ": Trigger Enter 2D - " + collision.gameObject.name);
    }
    private void OnTriggerStay(Collider collision) {
        if (trigger && stay)
            print(name + ": Trigger Stay 3D - " + collision.gameObject.name);
    }
    private void OnTriggerStay2D(Collider2D collision) {
        if (trigger && stay)
            print(name + ": Trigger Stay 2D - " + collision.gameObject.name);
    }
    private void OnTriggerExit(Collider collision) {
        if (trigger && exit)
            print(name + ": Trigger Exit 3D - " + collision.gameObject.name);
    }
    private void OnTriggerExit2D(Collider2D collision) {
        if (trigger && exit)
            print(name + ": Trigger Exit 2D - " + collision.gameObject.name);
    }
}
