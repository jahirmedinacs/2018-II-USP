﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SineMovement : MonoBehaviour {
    private new Rigidbody rigidbody;
    private Vector3 position;

    public float frequency, amplitude;

	void Start () {
        rigidbody = GetComponent<Rigidbody>();
        position = transform.position;
	}

	void Update () {
        rigidbody.MovePosition(position + Mathf.Sin(frequency * Time.time) * amplitude * Vector3.forward);
	}
}
