﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {
    public float force;

    private new Rigidbody rigidbody;

    private void Start() {
        rigidbody = GetComponent<Rigidbody>();
    }

    private void Update() {
        float x = Input.GetAxis("Horizontal");
        float y = Input.GetKey(KeyCode.Q) ? -1f : Input.GetKey(KeyCode.E) ? 1f : 0f;
        float z = Input.GetAxis("Vertical");

        rigidbody.AddForce(new Vector3(x, y, z).normalized * force);
    }
}
