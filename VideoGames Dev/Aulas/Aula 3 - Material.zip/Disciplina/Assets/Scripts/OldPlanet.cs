﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OldPlanet : MonoBehaviour {
    public float angularVelocity;

    private Transform _transform;
    private float angle;

    private void Start() {
        _transform = GetComponent<Transform>();
        angle = 0f;
    }


    private void Update() {
        angle += angularVelocity;
        _transform.eulerAngles = new Vector3(0f, angle, 0f);
        if (angle > 360f)
            angle = angle - 360f;
        if (angle < 360f)
            angle = angle + 360f;
    }
}
