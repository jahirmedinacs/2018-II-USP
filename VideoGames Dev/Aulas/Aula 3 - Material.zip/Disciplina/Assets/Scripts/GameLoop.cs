using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Random = Utils.Random;

using System;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;

using TMPro;

public class GameLoop : MonoBehaviour {
    public TextMeshProUGUI startText;
    public TextMeshProUGUI updateText;
    public TextMeshProUGUI totalText;
    public TextMeshProUGUI fixedUpdateText;

    public GameObject prefab;
    public int N;
    public string fileName;

    private Stopwatch startWatch;
    private Stopwatch updateWatch;
    private Stopwatch fixedUpdateWatch;


    static GameObject[] gameObjects;
    static Transform[] transforms;

    StreamWriter file;
    double awake;
    bool stop;
    bool property;

    private void Awake() {
        updateWatch = new Stopwatch();
        fixedUpdateWatch = new Stopwatch();
        startWatch = new Stopwatch();
        file = new StreamWriter(fileName);

        print("Awake");

        startWatch.Start();

        gameObjects = new GameObject[N];
        transforms = new Transform[N];

        for (int i = 0; i < N; i++) {
            gameObjects[i] = GameObject.Instantiate<GameObject>(prefab);
            transforms[i] = gameObjects[i].GetComponent<Transform>();
        }
        startWatch.Stop();

        awake = startWatch.Elapsed.TotalMilliseconds;
        startText.text = String.Format("Start {0,7:000.000}", awake);
        file.WriteLine(String.Format("Start {0,7:000.000}", awake));

        stop = false;
        property = true;
        updateWatch.Start();
        fixedUpdateWatch.Start();
    }
    long fixedUpdates;

    private void Update() {
        double draw = updateWatch.Elapsed.TotalMilliseconds;

        updateWatch.Reset();
        updateWatch.Start();

        if (Input.GetMouseButtonDown(1))
            property = !property;

        for (int i = 0; i < N; i++) {
            if (!property)
                transforms[i].position = new Vector3(0f, 0f, (float)Math.Sin(i * draw));
            else
                gameObjects[i].transform.position = new Vector3(0f, 0f, (float)Math.Sin(i * draw));
        }

        if (Input.GetMouseButtonDown(0))
            stop = !stop;

        updateWatch.Stop();

        double update = fixedUpdateWatch.Elapsed.TotalMilliseconds;

        if (!stop) {
            updateText.text = String.Format("Update {0,7:000.000} ({1,6:000.00} ups) property = {2}", update, 1000.0 / update, property);
            totalText.text = String.Format("Draw {0,7:000.000} ({1,6:000.00} fps)", draw, 1000.0 / draw);
        }

        print("Update " + draw);
        file.WriteLine(String.Format("Update {0,7:000.000} ({1,6:000.00} ups) property = {2}", update, 1000.0 / update, property));
        file.WriteLine(String.Format("Draw {0,7:000.000} ({1,6:000.00} fps)", draw, 1000.0 / draw));
        file.Flush();
        updateWatch.Reset();
        updateWatch.Start();
        fixedUpdates = 0;
    }

    private void FixedUpdate() {
        double fixedUpdate = fixedUpdateWatch.Elapsed.TotalMilliseconds;
        fixedUpdateWatch.Stop();
        fixedUpdates++;
        print("Fixed Update " + fixedUpdate);
        fixedUpdateText.text = String.Format("Fixed Update {0,7:000.000} ({1,5:00000} updates)", fixedUpdate, fixedUpdates);
        file.WriteLine(String.Format("Fixed Update {0,7:000.000} ({1,5:00000} updates)", fixedUpdate, fixedUpdates));
        file.Flush();
        fixedUpdateWatch.Reset();
        fixedUpdateWatch.Start();
    }
}