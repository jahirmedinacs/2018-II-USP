﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class CameraLookAt : MonoBehaviour {
    public Transform at;
    private void Update() {
        transform.rotation = Quaternion.LookRotation(at.position - transform.position);
    }
}
